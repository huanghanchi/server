# Semantic-Loss
This repo contains the code to reproduce experiments reported in the paper ["A Semantic Loss Function for Deep Learning with Symbolic Knowledge"](http://web.cs.ucla.edu/~guyvdb/papers/XuICML18.pdf), published in ICML 2018.

NB: To use the complex constraints code, this repo should be cloned with the --recursive flag.
